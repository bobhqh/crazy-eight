package com.example.comp4004f22a3101077008;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DirtiesContext
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ContextConfiguration(classes = Application.class)
public class AcceptanceTest {
    @Autowired
    GameData gd;
    @Autowired
    GameLogic game;
    @LocalServerPort
    int port;
    @Autowired
    GameController controller;

    @BeforeEach
    public void Before() {
        game = new GameLogic();
        gd = new NonRiggedData();
        controller = new GameController(game,gd);
        for(int i=0;i<4;i++){
            Player p = new Player(i+1);
            gd.getPlayers().add(p);
        }
        game.populateDeck(gd.getCards());
        game.shuffleDeck(gd.getCards());
    }
    @AfterEach
    public void After() {
        System.out.println("test complete");
    }
    public void getCard(Integer playerIndex,String cardStr) {
        Player p= gd.getPlayers().get(playerIndex-1);
        String [] str = cardStr.split("");
        String rank = str[0];
        String suit = str[1];
        ArrayList<Card> cards = gd.getCards();
        Card card = new Card(suit,rank);
        int cardIndex = cards.indexOf(card);
        p.addCard(cards.remove(cardIndex));
    }
    public void exchangeCardsFromGameCards(Integer playerIndex, List<String> cards) {
        ArrayList<Card> playerCards = gd.getPlayers().get(playerIndex - 1).cards;
        int l = playerCards.size() - cards.size();
        int r = playerCards.size()-1;
        for(int i = r ;i >=l; --i) {
            gd.getCards().add(playerCards.remove(i));
        }
        for(int i = 0;i<cards.size(); ++i) {
            getCard(playerIndex,cards.get(i));
        }
    }
    public void setTopCard(String cardStr) {
        String [] str = cardStr.split("");
        String rank = str[0];
        String suit = str[1];
        ArrayList<Card> cards = gd.getCards();
        Card card = new Card(suit,rank);
        int index = cards.indexOf(card);
        gd.setTopCard(cards.remove(index));
    }
    public boolean cantPlayAndMustDraw(Integer playerIndex) {
        for(Card card : gd.getPlayers().get(playerIndex-1).cards) {
            String cardStr = card.getRank() + card.getSuit();
            if (!game.playCard(gd.getPlayers().get(1),cardStr,gd.getTopCard()).equals("notplayed")) {
                return false;
            }
        }
        return true;
    }
    public boolean cardInPlayerHand(String cardStr,Integer playerIndex) {
        String [] str = cardStr.split("");
        String rank = str[0];
        String suit = str[1];
        Card card = new Card(suit, rank);
        for (Card tcard : gd.getPlayers().get(playerIndex-1).cards) {
            if (tcard.equals(card)) {
                return true;
            }
        }
        return false;
    }
    public void rigTestRow1() {
        getCard(1,"3C");
        getCard(1,"4C");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"3H");
        getCard(4,"4H");
        setTopCard("5C");
    }
    @Test
    public void testRow1() throws Exception {
        rigTestRow1();
        controller.playCard(new ConnectionMessage("1 3C"));
        assertEquals(false,cardInPlayerHand("3C",1));
        assertEquals(new Card("C","3"),gd.getTopCard());
        assertEquals(2,gd.getCurrentPlayer());
    }
    public void rigTestRow2() {
        getCard(1,"3C");
        getCard(1,"4C");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"3H");
        getCard(4,"4H");

        getCard(1,"AH");
        getCard(4,"7H");
        setTopCard("5H");
    }
    @Test
    public void testRow2() throws Exception {
        rigTestRow2();
        controller.playCard(new ConnectionMessage("1 AH"));
        assertEquals(false,cardInPlayerHand("AH",1));
        assertEquals(new Card("H","A"),gd.getTopCard());
        assertEquals(4,gd.getCurrentPlayer());
        controller.playCard(new ConnectionMessage("4 7H"));
        assertEquals(false,cardInPlayerHand("7H",4));
        assertEquals(new Card("H","7"),gd.getTopCard());
        assertEquals(3,gd.getCurrentPlayer());
    }
    public void rigTestRow3() {
        getCard(1,"3C");
        getCard(1,"4C");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"3H");
        getCard(4,"4H");
        getCard(1,"QC");
        setTopCard("5C");
    }
    @Test
    public void testRow3() throws Exception {
        rigTestRow3();
        controller.playCard(new ConnectionMessage("1 QC"));
        assertEquals(false,cardInPlayerHand("QC",1));
        assertEquals(new Card("C","Q"),gd.getTopCard());
        assertEquals(3,gd.getCurrentPlayer());
    }
    public void rigTestRow4() {
        getCard(1,"3H");
        getCard(1,"4C");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"3C");
        getCard(4,"4H");
        setTopCard("5C");
    }
    @Test
    public void testRow4() throws Exception {
        rigTestRow4();
        gd.setCurrentPlayer(4);
        controller.playCard(new ConnectionMessage("4 3C"));
        assertEquals(false,cardInPlayerHand("3C",4));
        assertEquals(new Card("C","3"),gd.getTopCard());
        assertEquals(1,gd.getCurrentPlayer());
    }
    public void rigTestRow5() {
        getCard(1,"3C");
        getCard(1,"4C");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"3H");
        getCard(4,"4H");

        getCard(4,"AH");
        setTopCard("5H");
    }
    @Test
    public void testRow5() throws Exception {
        rigTestRow5();
        gd.setCurrentPlayer(4);
        controller.playCard(new ConnectionMessage("4 AH"));
        assertEquals(false,cardInPlayerHand("AH",4));
        assertEquals(new Card("H","A"),gd.getTopCard());
        assertEquals(3,gd.getCurrentPlayer());
    }
    public void rigTestRow6() {
        getCard(1,"3C");
        getCard(1,"4C");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"3H");
        getCard(4,"4H");

        getCard(4,"QC");
        setTopCard("5C");
    }
    @Test
    public void testRow6() throws Exception {
        rigTestRow6();
        gd.setCurrentPlayer(4);
        assertEquals(new Card("C","5"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("4 QC"));
        assertEquals(false,cardInPlayerHand("QC",4));
        assertEquals(new Card("C","Q"),gd.getTopCard());
        assertEquals(2,gd.getCurrentPlayer());
    }
    public void rigTestRow7() {
        getCard(1,"3C");
        getCard(1,"4C");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"3H");
        getCard(4,"4H");

        getCard(1,"KH");
        setTopCard("KC");
    }
    @Test
    public void testRow7() throws Exception {
        rigTestRow7();
        assertEquals(new Card("C","K"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("1 KH"));
        assertEquals(false,cardInPlayerHand("KH",1));
        assertEquals(new Card("H","K"),gd.getTopCard());
        assertEquals(2,gd.getCurrentPlayer());
    }
    public void rigTestRow8() {
        getCard(1,"3C");
        getCard(1,"4C");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"3H");
        getCard(4,"4H");

        getCard(1,"7C");
        setTopCard("KC");
    }
    @Test
    public void testRow8() throws Exception {
        rigTestRow8();
        assertEquals(new Card("C","K"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("1 7C"));
        assertEquals(false,cardInPlayerHand("7C",1));
        assertEquals(new Card("C","7"),gd.getTopCard());
        assertEquals(2,gd.getCurrentPlayer());
    }
    public void rigTestRow9() {
        getCard(1,"3C");
        getCard(1,"4C");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"3H");
        getCard(4,"4H");

        getCard(1,"8H");
        setTopCard("KC");
    }
    @Test
    public void testRow9() throws Exception {
        rigTestRow9();
        assertEquals(new Card("C","K"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("1 8H"));
        assertEquals(new Card("H","8"),gd.getTopCard());
        controller.changeSuit(new ConnectionMessage("H"));
        assertEquals(new Card("H",""),gd.getTopCard());
        assertEquals(2,gd.getCurrentPlayer());
    }

    public void rigTestRow10() {
        getCard(1,"3C");
        getCard(1,"4C");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"3H");
        getCard(4,"4H");

        getCard(1,"5S");
        setTopCard("KC");
    }
    @Test
    public void testRow10() throws Exception {
        rigTestRow10();
        assertEquals(new Card("C","K"),gd.getTopCard());
        PlayMessage playMessage = controller.playCard(new ConnectionMessage("1 5S"));
        assertEquals("NotPlayed",playMessage.getContent());
        assertEquals(true,cardInPlayerHand("5S",1));
        assertEquals(new Card("C","K"),gd.getTopCard());
        assertEquals(1,gd.getCurrentPlayer());
    }
    public void rigTestRow11() {
        getCard(1,"3H");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"4H");

        setTopCard("7C");
    }
    @Test
    public void testRow11() throws Exception {
        rigTestRow11();
        assertEquals(new Card("C","7"),gd.getTopCard());
        assertEquals(true, cantPlayAndMustDraw(1));
        getCard(1,"6C");
        DrawMessage drawMessage = controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("6C",1));
        assertEquals("noMoreDraw",drawMessage.getContent());
        controller.playCard(new ConnectionMessage("1 6C"));
        assertEquals(2,gd.getCurrentPlayer());
    }
    public void rigTestRow12() {
        getCard(1,"3H");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"4H");

        setTopCard("7C");
    }
    @Test
    public void testRow12() throws Exception {
        rigTestRow12();
        assertEquals(new Card("C","7"),gd.getTopCard());
        assertEquals(true, cantPlayAndMustDraw(1));
        getCard(1,"6D");
        DrawMessage drawMessage1 = controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("6D",1));
        assertEquals("draw",drawMessage1.getContent());
        getCard(1,"5C");
        DrawMessage drawMessage2 = controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("5C",1));
        assertEquals("noMoreDraw",drawMessage2.getContent());
        controller.playCard(new ConnectionMessage("1 5C"));
        assertEquals(2,gd.getCurrentPlayer());
    }
    public void rigTestRow13() {
        getCard(1,"3H");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"4H");

        setTopCard("7C");
    }
    @Test
    public void testRow13() throws Exception {
        rigTestRow13();
        assertEquals(new Card("C","7"),gd.getTopCard());
        assertEquals(true, cantPlayAndMustDraw(1));
        getCard(1,"6D");
        DrawMessage drawMessage1 = controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("6D",1));
        assertEquals("draw",drawMessage1.getContent());
        getCard(1,"5S");
        DrawMessage drawMessage2 = controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("5S",1));
        assertEquals("draw",drawMessage2.getContent());
        getCard(1,"7H");
        DrawMessage drawMessage3 = controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("7H",1));
        assertEquals("noMoreDraw",drawMessage3.getContent());
        controller.playCard(new ConnectionMessage("1 7H"));
        assertEquals(2,gd.getCurrentPlayer());
    }
    public void rigTestRow14() {
        getCard(1,"3H");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"5H");

        setTopCard("7C");
    }
    @Test
    public void testRow14() throws Exception {
        rigTestRow14();
        assertEquals(new Card("C","7"),gd.getTopCard());
        assertEquals(true, cantPlayAndMustDraw(1));
        getCard(1,"6D");
        DrawMessage drawMessage1 = controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("6D",1));
        assertEquals("draw",drawMessage1.getContent());
        getCard(1,"5S");
        DrawMessage drawMessage2 = controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("5S",1));
        assertEquals("draw",drawMessage2.getContent());
        getCard(1,"4H");
        DrawMessage drawMessage3 = controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("4H",1));
        assertEquals("Not Playable",drawMessage3.getContent());
        assertEquals(2,gd.getCurrentPlayer());
    }
    public void rigTestRow15() {
        getCard(1,"3H");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"4H");

        setTopCard("7C");
    }
    @Test
    public void testRow15() throws Exception {
        rigTestRow15();
        assertEquals(new Card("C","7"),gd.getTopCard());
        assertEquals(true, cantPlayAndMustDraw(1));
        getCard(1,"6D");
        DrawMessage drawMessage1 = controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("6D",1));
        assertEquals("draw",drawMessage1.getContent());
        getCard(1,"8H");
        DrawMessage drawMessage2 = controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("8H",1));
        assertEquals("noMoreDraw",drawMessage2.getContent());
        controller.playCard(new ConnectionMessage("1 8H"));
        assertEquals(2,gd.getCurrentPlayer());
    }

    public void rigTestRow16() {
        getCard(1,"3C");
        getCard(1,"KS");
        getCard(2,"3S");
        getCard(2,"4S");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"4H");

        setTopCard("7C");
    }
    @Test
    public void testRow16() throws Exception {
        rigTestRow16();
        assertEquals(new Card("C","7"),gd.getTopCard());
        getCard(1,"6C");
        DrawMessage drawMessage1 = controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("6C",1));
        assertEquals("noMoreDraw",drawMessage1.getContent());
        controller.playCard(new ConnectionMessage("1 6C"));
        assertEquals(false,cardInPlayerHand("6C",1));
        assertEquals(new Card("C","6"),gd.getTopCard());
        assertEquals(2,gd.getCurrentPlayer());
    }
    public void rigTestRow17() {
        getCard(1,"3C");
        getCard(1,"2C");
        getCard(2,"4H");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"4C");

        setTopCard("7C");
    }
    @Test
    public void testRow17() throws Exception {
        rigTestRow17();
        assertEquals(new Card("C","7"),gd.getTopCard());
        PlayMessage playMessage = controller.playCard(new ConnectionMessage("1 2C"));
        assertEquals(false,cardInPlayerHand("2C",1));
        assertEquals(new Card("C","2"),gd.getTopCard());
        assertEquals("2 Played 1",playMessage.getContent());
        assertEquals(2,gd.getCurrentPlayer());

        exchangeCardsFromGameCards(2,new ArrayList<>(Arrays.asList("6C", "9D")));
        controller.playCard(new ConnectionMessage("2 6C"));
        assertEquals(false,cardInPlayerHand("6C",2));
        assertEquals(new Card("C","6"),gd.getTopCard());
        assertEquals(3,gd.getCurrentPlayer());
    }
    public void rigTestRow18() {
        getCard(1,"3C");
        getCard(1,"2C");
        getCard(2,"4H");
        getCard(3,"3D");
        getCard(3,"4D");
        getCard(4,"4C");

        setTopCard("7C");
    }
    @Test
    public void testRow18() throws Exception {
        rigTestRow18();
        assertEquals(new Card("C","7"),gd.getTopCard());
        PlayMessage playMessage = controller.playCard(new ConnectionMessage("1 2C"));
        assertEquals(false,cardInPlayerHand("2C",2));
        assertEquals(new Card("C","2"),gd.getTopCard());
        assertEquals("2 Played 1",playMessage.getContent());
        assertEquals(2,gd.getCurrentPlayer());

        exchangeCardsFromGameCards(2,new ArrayList<>(Arrays.asList("6S", "9D")));
        assertEquals(true, cantPlayAndMustDraw(2));
        getCard(2,"9H");
        DrawMessage drawMessage1 = controller.realDrawCard(new ConnectionMessage("2"),true);
        assertEquals(true,cardInPlayerHand("9H",2));
        assertEquals("draw",drawMessage1.getContent());
        getCard(2,"6C");
        DrawMessage drawMessage2 = controller.realDrawCard(new ConnectionMessage("2"),true);
        assertEquals(true,cardInPlayerHand("6C",2));
        assertEquals("noMoreDraw",drawMessage2.getContent());
        controller.playCard(new ConnectionMessage("2 6C"));
        assertEquals(false,cardInPlayerHand("6C",2));
        assertEquals(new Card("C","6"),gd.getTopCard());
        assertEquals(3,gd.getCurrentPlayer());
    }
    public void rigTestRow19() {
        getCard(1,"3C");
        getCard(1,"2C");
        getCard(2,"4H");
        getCard(3,"3D");
        getCard(4,"4C");

        setTopCard("7C");
    }
    @Test
    public void testRow19() throws Exception {
        rigTestRow19();
        assertEquals(new Card("C","7"),gd.getTopCard());
        PlayMessage playMessage = controller.playCard(new ConnectionMessage("1 2C"));
        assertEquals(false,cardInPlayerHand("2C",2));
        assertEquals(new Card("C","2"),gd.getTopCard());
        assertEquals("2 Played 1",playMessage.getContent());
        exchangeCardsFromGameCards(2,new ArrayList<>(Arrays.asList("6S", "9D")));
        assertEquals(2,gd.getCurrentPlayer());

        assertEquals(true, cantPlayAndMustDraw(2));
        getCard(2,"9H");
        DrawMessage drawMessage1 = controller.realDrawCard(new ConnectionMessage("2"),true);
        assertEquals(true,cardInPlayerHand("9H",2));
        assertEquals("draw",drawMessage1.getContent());
        getCard(2,"7S");
        DrawMessage drawMessage2 = controller.realDrawCard(new ConnectionMessage("2"),true);
        assertEquals(true,cardInPlayerHand("7S",2));
        assertEquals("draw",drawMessage1.getContent());
        getCard(2,"5H");
        DrawMessage drawMessage3 = controller.realDrawCard(new ConnectionMessage("2"),true);
        assertEquals(true,cardInPlayerHand("5H",2));
        assertEquals("Not Playable",drawMessage3.getContent());
        assertEquals(3,gd.getCurrentPlayer());
    }
    public void rigTestRow20() {
        getCard(1,"3C");
        getCard(1,"2C");
        getCard(2,"4H");
        getCard(3,"7D");
        getCard(4,"4C");

        setTopCard("5C");
    }
    @Test
    public void testRow20() throws Exception {
        rigTestRow20();
        assertEquals(new Card("C","5"),gd.getTopCard());
        PlayMessage playMessage1 = controller.playCard(new ConnectionMessage("1 2C"));
        assertEquals(false,cardInPlayerHand("2C",1));
        assertEquals(new Card("C","2"),gd.getTopCard());
        assertEquals("2 Played 1",playMessage1.getContent());
        exchangeCardsFromGameCards(2,new ArrayList<>(Arrays.asList("2H", "9D")));
        assertEquals(2,gd.getCurrentPlayer());

        PlayMessage playMessage2 = controller.playCard(new ConnectionMessage("2 2H"));
        assertEquals(false,cardInPlayerHand("2H",2));
        assertEquals(new Card("H","2"),gd.getTopCard());
        assertEquals("2 Played 1",playMessage2.getContent());
        exchangeCardsFromGameCards(3,new ArrayList<>(Arrays.asList("5S", "6D","6H","7C")));
        assertEquals(3,gd.getCurrentPlayer());

        controller.playCard(new ConnectionMessage("3 6H"));
        assertEquals(false,cardInPlayerHand("6H",3));
        assertEquals(new Card("H","6"),gd.getTopCard());
        assertEquals(4,gd.getCurrentPlayer());
    }
    public void rigTestRow21() {
        getCard(1,"3C");
        getCard(1,"2C");
        getCard(2,"4C");
        getCard(2,"6C");
        getCard(2,"9D");
        getCard(3,"7D");
        getCard(4,"7C");

        setTopCard("5C");
    }
    @Test
    public void testRow21() throws Exception {
        rigTestRow21();
        assertEquals(new Card("C","5"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("1 2C"));
        assertEquals(false,cardInPlayerHand("2C",3));
        assertEquals(new Card("C","2"),gd.getTopCard());
        assertEquals(2,gd.getCurrentPlayer());

        controller.playCard(new ConnectionMessage("2 4C"));
        assertEquals(false,cardInPlayerHand("4C",2));
        assertEquals(new Card("C","4"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("2 6C"));
        assertEquals(false,cardInPlayerHand("6C",2));
        assertEquals(new Card("C","6"),gd.getTopCard());
        assertEquals(3,gd.getCurrentPlayer());
    }
    public void rigTestRow22() {
        getCard(1,"3C");
        getCard(1,"2C");
        getCard(2,"4C");
        getCard(2,"4S");
        getCard(3,"7D");
        getCard(4,"7C");

        setTopCard("5C");
    }
    @Test
    public void testRow22() throws Exception {
        rigTestRow22();
        assertEquals(new Card("C","5"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("1 2C"));
        assertEquals(false,cardInPlayerHand("2C",1));
        assertEquals(new Card("C","2"),gd.getTopCard());
        assertEquals(2,gd.getCurrentPlayer());

        controller.playCard(new ConnectionMessage("2 4C"));
        assertEquals(false,cardInPlayerHand("4C",2));
        assertEquals(new Card("C","4"),gd.getTopCard());
        PlayMessage playMessage = controller.playCard(new ConnectionMessage("2 4S"));
        assertEquals("Round Over",playMessage.getContent());
    }
    public void rigTestRow23() {
        getCard(1,"AS");
        getCard(1,"3C");
        getCard(2,"4C");
        getCard(3,"6H");
        getCard(3,"8H");
        getCard(3,"JH");
        getCard(3,"KH");
        getCard(3,"KS");
        getCard(4,"8C");
        getCard(4,"8D");
        getCard(4,"2D");

        setTopCard("5C");
    }
    @Test
    public void testRow23() throws Exception {
        rigTestRow23();

        controller.playCard(new ConnectionMessage("1 3C"));
        controller.playCard(new ConnectionMessage("2 4C"));
        assertEquals(1,gd.getPlayers().get(0).getScore());
        assertEquals(0,gd.getPlayers().get(1).getScore());
        assertEquals(86,gd.getPlayers().get(2).getScore());
        assertEquals(102,gd.getPlayers().get(3).getScore());
    }
    public void rigTestRow24() {
        getCard(1,"4H");
        getCard(1,"7S");
        getCard(1,"5D");
        getCard(1,"6D");
        getCard(1,"9D");

        getCard(2,"4S");
        getCard(2,"6S");
        getCard(2,"KC");
        getCard(2,"8H");
        getCard(2,"TD");

        getCard(3,"9S");
        getCard(3,"6C");
        getCard(3,"9C");
        getCard(3,"JD");
        getCard(3,"3H");

        getCard(4,"7D");
        getCard(4,"JH");
        getCard(4,"QH");
        getCard(4,"KH");
        getCard(4,"5C");

        setTopCard("4D");
    }
    @Test
    public void testRow24() throws Exception {
        rigTestRow24();
        DrawMessage drawMessage;
        PlayMessage playMessage;
        controller.playCard(new ConnectionMessage("1 4H"));
        assertEquals(false,cardInPlayerHand("4H",1));
        assertEquals(new Card("H","4"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("2 4S"));
        assertEquals(false,cardInPlayerHand("4S",2));
        assertEquals(new Card("S","4"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("3 9S"));
        assertEquals(false,cardInPlayerHand("9S",3));
        assertEquals(new Card("S","9"),gd.getTopCard());

        assertEquals(true, cantPlayAndMustDraw(4));
        getCard(4,"2C");
        drawMessage = controller.realDrawCard(new ConnectionMessage("4"),true);
        assertEquals(true,cardInPlayerHand("2C",4));
        assertEquals("draw",drawMessage.getContent());
        getCard(4,"3C");
        drawMessage = controller.realDrawCard(new ConnectionMessage("4"),true);
        assertEquals(true,cardInPlayerHand("3C",4));
        assertEquals("draw",drawMessage.getContent());
        getCard(4,"4C");
        drawMessage = controller.realDrawCard(new ConnectionMessage("4"),true);
        assertEquals(true,cardInPlayerHand("4C",4));
        assertEquals("Not Playable",drawMessage.getContent());
        assertEquals(1,gd.getCurrentPlayer());

        controller.playCard(new ConnectionMessage("1 7S"));
        assertEquals(false,cardInPlayerHand("7S",1));
        assertEquals(new Card("S","7"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("2 6S"));
        assertEquals(false,cardInPlayerHand("6S",2));
        assertEquals(new Card("S","6"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("3 6C"));
        assertEquals(false,cardInPlayerHand("6C",3));
        assertEquals(new Card("C","6"),gd.getTopCard());
        playMessage = controller.playCard(new ConnectionMessage("4 2C"));
        assertEquals(false,cardInPlayerHand("2C",4));
        assertEquals(new Card("C","2"),gd.getTopCard());
        assertEquals("2 Played 1",playMessage.getContent());
        exchangeCardsFromGameCards(1,new ArrayList<>(Arrays.asList("TC", "JC")));

        controller.playCard(new ConnectionMessage("1 JC"));
        assertEquals(false,cardInPlayerHand("JC",1));
        assertEquals(new Card("C","J"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("2 KC"));
        assertEquals(false,cardInPlayerHand("KC",2));
        assertEquals(new Card("C","K"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("3 9C"));
        assertEquals(false,cardInPlayerHand("9C",3));
        assertEquals(new Card("C","9"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("4 3C"));
        assertEquals(false,cardInPlayerHand("3C",4));
        assertEquals(new Card("C","3"),gd.getTopCard());

        getCard(1,"7C");
        controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("7C",1));
        controller.playCard(new ConnectionMessage("1 7C"));
        assertEquals(false,cardInPlayerHand("7C",1));
        assertEquals(new Card("C","7"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("2 8H"));
        assertEquals(false,cardInPlayerHand("8H",2));
        assertEquals(new Card("H","8"),gd.getTopCard());
        controller.changeSuit(new ConnectionMessage("D"));
        assertEquals(new Card("D",""),gd.getTopCard());
        controller.playCard(new ConnectionMessage("3 JD"));
        assertEquals(false,cardInPlayerHand("JD",3));
        assertEquals(new Card("D","J"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("4 7D"));
        assertEquals(false,cardInPlayerHand("7D",4));
        assertEquals(new Card("D","7"),gd.getTopCard());

        controller.playCard(new ConnectionMessage("1 9D"));
        assertEquals(false,cardInPlayerHand("9D",1));
        assertEquals(new Card("D","9"),gd.getTopCard());
        playMessage = controller.playCard(new ConnectionMessage("2 TD"));
        assertEquals(false,cardInPlayerHand("TD",2));

        assertEquals("Round Over",playMessage.getContent());
        assertEquals(21,gd.getPlayers().get(0).getScore());
        assertEquals(0,gd.getPlayers().get(1).getScore());
        assertEquals(3,gd.getPlayers().get(2).getScore());
        assertEquals(39,gd.getPlayers().get(3).getScore());

        gd.getCards().add(gd.getTopCard());

        for (Player player:gd.getPlayers()) {
            while(!player.cards.isEmpty()){
                gd.getCards().add(player.cards.remove(0));
            }
        }

        getCard(1,"7D");
        getCard(1,"4S");
        getCard(1,"7C");
        getCard(1,"4H");
        getCard(1,"5D");

        getCard(2,"9D");
        getCard(2,"3S");
        getCard(2,"9C");
        getCard(2,"3H");
        getCard(2,"JC");

        getCard(3,"3D");
        getCard(3,"9S");
        getCard(3,"3C");
        getCard(3,"9H");
        getCard(3,"5H");

        getCard(4,"4D");
        getCard(4,"7S");
        getCard(4,"4C");
        getCard(4,"5S");
        getCard(4,"8D");

        setTopCard("TD");

        assertEquals(2,gd.getCurrentPlayer());
        controller.playCard(new ConnectionMessage("2 9D"));
        assertEquals(false,cardInPlayerHand("9D",2));
        assertEquals(new Card("D","9"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("3 3D"));
        assertEquals(false,cardInPlayerHand("3D",3));
        assertEquals(new Card("D","3"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("4 4D"));
        assertEquals(false,cardInPlayerHand("4D",4));
        assertEquals(new Card("D","4"),gd.getTopCard());

        controller.playCard(new ConnectionMessage("1 4S"));
        assertEquals(false,cardInPlayerHand("4S",1));
        assertEquals(new Card("S","4"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("2 3S"));
        assertEquals(false,cardInPlayerHand("3S",2));
        assertEquals(new Card("S","3"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("3 9S"));
        assertEquals(false,cardInPlayerHand("9S",3));
        assertEquals(new Card("S","9"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("4 7S"));
        assertEquals(false,cardInPlayerHand("7S",4));
        assertEquals(new Card("S","7"),gd.getTopCard());

        controller.playCard(new ConnectionMessage("1 7C"));
        assertEquals(false,cardInPlayerHand("7C",1));
        assertEquals(new Card("C","7"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("2 9C"));
        assertEquals(false,cardInPlayerHand("9C",2));
        assertEquals(new Card("C","9"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("3 3C"));
        assertEquals(false,cardInPlayerHand("3C",3));
        assertEquals(new Card("C","3"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("4 4C"));
        assertEquals(false,cardInPlayerHand("4C",4));
        assertEquals(new Card("C","4"),gd.getTopCard());

        controller.playCard(new ConnectionMessage("1 4H"));
        assertEquals(false,cardInPlayerHand("4H",1));
        assertEquals(new Card("H","4"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("2 3H"));
        assertEquals(false,cardInPlayerHand("3H",2));
        assertEquals(new Card("H","3"),gd.getTopCard());
        controller.playCard(new ConnectionMessage("3 9H"));
        assertEquals(false,cardInPlayerHand("9H",3));
        assertEquals(new Card("H","9"),gd.getTopCard());

        getCard(4,"KS");
        drawMessage = controller.realDrawCard(new ConnectionMessage("4"),true);
        assertEquals(true,cardInPlayerHand("KS",4));
        assertEquals("draw",drawMessage.getContent());
        getCard(4,"QS");
        drawMessage = controller.realDrawCard(new ConnectionMessage("4"),true);
        assertEquals(true,cardInPlayerHand("QS",4));
        assertEquals("draw",drawMessage.getContent());
        getCard(4,"KH");
        drawMessage = controller.realDrawCard(new ConnectionMessage("4"),true);
        assertEquals(true,cardInPlayerHand("KH",4));
        assertEquals("noMoreDraw",drawMessage.getContent());
        controller.playCard(new ConnectionMessage("4 KH"));
        assertEquals(false,cardInPlayerHand("KH",4));
        assertEquals(new Card("H","K"),gd.getTopCard());

        assertEquals(true, cantPlayAndMustDraw(1));
        getCard(1,"6D");
        drawMessage = controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("6D",1));
        assertEquals("draw",drawMessage.getContent());
        getCard(1,"QD");
        drawMessage = controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("QD",1));
        assertEquals("draw",drawMessage.getContent());
        getCard(1,"JD");
        drawMessage = controller.realDrawCard(new ConnectionMessage("1"),true);
        assertEquals(true,cardInPlayerHand("JD",1));
        assertEquals("Not Playable",drawMessage.getContent());

        assertEquals(true, cantPlayAndMustDraw(2));
        getCard(2,"6S");
        drawMessage = controller.realDrawCard(new ConnectionMessage("2"),true);
        assertEquals(true,cardInPlayerHand("6S",2));
        assertEquals("draw",drawMessage.getContent());
        getCard(2,"JS");
        drawMessage = controller.realDrawCard(new ConnectionMessage("2"),true);
        assertEquals(true,cardInPlayerHand("JS",2));
        assertEquals("draw",drawMessage.getContent());
        getCard(2,"TS");
        drawMessage = controller.realDrawCard(new ConnectionMessage("2"),true);
        assertEquals(true,cardInPlayerHand("TS",2));
        assertEquals("Not Playable",drawMessage.getContent());

        playMessage = controller.playCard(new ConnectionMessage("3 5H"));
        assertEquals("Game Over",playMessage.getContent());
        assertEquals(59,gd.getPlayers().get(0).getScore());
        assertEquals(36,gd.getPlayers().get(1).getScore());
        assertEquals(3,gd.getPlayers().get(2).getScore());
        assertEquals(114,gd.getPlayers().get(3).getScore());
    }
}
